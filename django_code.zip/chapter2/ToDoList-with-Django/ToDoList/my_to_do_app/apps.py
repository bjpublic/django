from django.apps import AppConfig


class MyToDoAppConfig(AppConfig):
    name = 'my_to_do_app'
